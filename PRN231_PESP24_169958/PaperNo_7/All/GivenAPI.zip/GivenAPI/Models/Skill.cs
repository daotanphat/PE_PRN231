﻿namespace GivenAPI.Models
{
    public class Skill
    {
        public int SkillId { get; set; }
        public string SkillName { get; set; } = null!;
    }
}
